package com.coderby.myapp.hr;

public class EmpMain {
	public static void main(String[] args) {

	}
}